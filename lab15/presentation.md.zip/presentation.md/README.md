# Шаблон статьи

## Скачать репозиторий

git clone https://github.com/yamadharma/academic-presentation-markdown-template.git

