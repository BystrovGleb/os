---
## Front matter
lang: ru-RU
title: Отчёт по лабораторной работе №15
author: |
	Быстров Г. Андреевич
institute: |
	RUDN University, Moscow, Russian Federation
date: 2021, 10 июня Москва, Россия

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---

## Прагматика

- получить практические знания программирования;
- решить возникающие трудности и проблемы;
- практически получить полезный результат.

## Цель работы

- приобрести практические навыки работы с именованными каналами.

## Задачи

1. Изучил приведённые в тексте программы server.c и client.c. Взяв данные примеры за образец, написал аналогичные программы, внеся изменения. (рис. -@fig:001) 

![Файл common.h](image/image1.jpg){ #fig:001 width=70% }

## Задачи

2. Работает не 1 клиент, а несколько. Клиенты передают текущее время с некоторой периодичностью. Использовал функцию sleep() для приостановки работы клиента. (рис. -@fig:002) 

![Файл Makefile](image/image2.jpg){ #fig:002 width=70% }

## Задачи

3. Сервер работает не бесконечно, а прекращает работу через некоторое время. Использовал функцию clock() для определения времени работы сервера. (рис. -@fig:003) 

![Демонстрация работы](image/image3.jpg){ #fig:003 width=90% }

## Результаты

- успешно удалось приобрести практические навыки работы с именованными каналами.

