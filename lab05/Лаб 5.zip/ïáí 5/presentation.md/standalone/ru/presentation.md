---
## Front matter
lang: ru-RU
title: Отчёт по лабораторной работе №3
author: |
	Быстров Г. Андреевич
institute: |
	RUDN University, Moscow, Russian Federation
date: 2021, 10 мая Москва, Россия

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---

## Прагматика

- получить практические знания оформления отчётов с помощью легковесного языка разметки Markdown.
- решить возникающие трудности и проблемы;
- практически получить полезный результат.

## Цель работы

- научиться оформлять отчёты с помощью легковесного языка разметки Markdown.

## Задачи

1. Провести работу с текстом с помощью Markdown.(рис. -@fig:001)

![Работа с текстом](image/image1.png){ #fig:001 width=70% }

## Задачи

2. Перевести файл Markdown в форматы pdf и docx. (рис. -@fig:002)

![Готовые файлы](image/image2.png){ #fig:002 width=70% }

## Результаты

- успешно удалось приобрести практические навыки оформления отчётов с помощью легковесного языка разметки Markdown.

