---
## Front matter
lang: ru-RU
title: Отчёт по лабораторной работе №14
author: |
	Быстров Г. Андреевич
institute: |
	RUDN University, Moscow, Russian Federation
date: 2021, 4 июня Москва, Россия

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---

## Прагматика

- получить практические знания программирования;
- решить возникающие трудности и проблемы;
- практически получить полезный результат.

## Цель работы

- приобрести навыки разработки, анализа, тестирования и отладки приложений в ОС типа UNIX/Linux на примере создания на языке программирования С калькулятора с простейшими функциями.

## Задачи

1. Выполнил компиляцию программы посредством gcc. (рис. -@fig:001) 

![gcc](image/image1.jpg){ #fig:001 width=70% }

## Задачи

2. Создал Makefile. (рис. -@fig:002) 

![Makefile](image/image2.jpg){ #fig:002 width=60% }

## Задачи

3. С помощью gdb выполнил отладку программы calcul. С помощью утилиты splint проанализировал коды файлов calculate.c и main.c.

![Отладка программы calcul](image/image3.jpg){ #fig:003 width=70% }

## Результаты

- успешно удалось приобрести навыки разработки, анализа, тестирования и отладки приложений в ОС типа UNIX/Linux на примере создания на языке программирования С калькулятора с простейшими функциями.

