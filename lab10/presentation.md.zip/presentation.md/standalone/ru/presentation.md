---
## Front matter
lang: ru-RU
title: Отчёт по лабораторной работе №10
author: |
	Быстров Г. Андреевич
institute: |
	RUDN University, Moscow, Russian Federation
date: 2021, 15 мая Москва, Россия

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---

## Прагматика

- получить практические знания во время работы с редактором Emacs.
- решить возникающие трудности и проблемы;
- практически получить полезный результат.

## Цель работы

- познакомиться с операционной системой Linux;
- преобрести практические навыки работы с редактором Emacs.

## Задачи

1. Сохранять, вырезать, копировать, вставлять текст и создавать файлы в редакторе Emacs. (рис. -@fig:001) 

![Редактирование текста](image/image1.jpg){ #fig:001 width=70% }

## Задачи

2. Перемещать курсор в редакторе. Делить фрейм на разные окна. (рис. -@fig:002) 

![Перемещение курсора](image/image2.jpg){ #fig:002 width=70% }

## Задачи

3. Искать и заменять слова в тексте. (рис. -@fig:003)

![Поиск в тексте](image/image3.jpg){ #fig:003 width=70% }

## Результаты

- успешно удалось приобрести практические навыки работы с редактором Emacs;
- познакомиться с операционной системой Linux.

